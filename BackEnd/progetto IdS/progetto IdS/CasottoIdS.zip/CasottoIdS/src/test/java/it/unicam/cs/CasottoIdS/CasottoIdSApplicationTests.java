package it.unicam.cs.CasottoIdS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasottoIdSApplicationTests {

	@Test
	void contextLoads() {
	}

}
